const express = require("express");
const path = require("path");
const { Pool } = require("pg");

const app = express();
app.use(express.json());

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL ? { rejectUnauthorized: false } : false
});

const ALLOWED_TABLES = new Set([
  "caminhoes",
  "motoristas",
  "viagens",
  "despesas",
  "manutencoes",
  "documentos"
]);

function assertTable(table) {
  if (!ALLOWED_TABLES.has(table)) {
    const err = new Error("Tabela não permitida");
    err.status = 400;
    throw err;
  }
}

async function ensureTables() {
  for (const t of ALLOWED_TABLES) {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS ${t} (
        id BIGSERIAL PRIMARY KEY,
        data JSONB NOT NULL DEFAULT '{}'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
      );
    `);

    await pool.query(`
      CREATE INDEX IF NOT EXISTS ${t}_data_gin ON ${t} USING GIN (data);
    `);
  }
  console.log("Tabelas criadas/verificadas.");
}

function handleError(res, e) {
  console.error(e);
  res.status(e.status || 500).json({ error: e.message || "Erro interno" });
}

app.get("/tables/:table", async (req, res) => {
  try {
    const { table } = req.params;
    assertTable(table);

    const result = await pool.query(`SELECT id, data FROM ${table} ORDER BY id DESC`);
    const data = result.rows.map(r => ({ id: r.id, ...r.data }));

    res.json({ data, count: data.length });
  } catch (e) {
    handleError(res, e);
  }
});

app.post("/tables/:table", async (req, res) => {
  try {
    const { table } = req.params;
    assertTable(table);

    const payload = req.body || {};
    const result = await pool.query(
      `INSERT INTO ${table} (data) VALUES ($1::jsonb) RETURNING id, data`,
      [JSON.stringify(payload)]
    );

    res.status(201).json({ data: { id: result.rows[0].id, ...result.rows[0].data } });
  } catch (e) {
    handleError(res, e);
  }
});

app.put("/tables/:table/:id", async (req, res) => {
  try {
    const { table, id } = req.params;
    assertTable(table);

    const payload = req.body || {};
    const result = await pool.query(
      `UPDATE ${table} SET data = $1::jsonb, updated_at = now() WHERE id = $2 RETURNING id, data`,
      [JSON.stringify(payload), id]
    );

    if (!result.rowCount) return res.status(404).json({ error: "Registro não encontrado" });

    res.json({ data: { id: result.rows[0].id, ...result.rows[0].data } });
  } catch (e) {
    handleError(res, e);
  }
});

app.delete("/tables/:table/:id", async (req, res) => {
  try {
    const { table, id } = req.params;
    assertTable(table);

    const result = await pool.query(`DELETE FROM ${table} WHERE id = $1`, [id]);
    if (!result.rowCount) return res.status(404).json({ error: "Registro não encontrado" });

    res.json({ ok: true });
  } catch (e) {
    handleError(res, e);
  }
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

const port = process.env.PORT || 3000;

ensureTables()
  .then(() => {
    app.listen(port, () => console.log(`Servidor rodando na porta ${port}`));
  })
  .catch((e) => {
    console.error("Erro ao iniciar:", e);
    process.exit(1);
  });
