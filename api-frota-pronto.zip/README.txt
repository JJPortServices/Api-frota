API pronta para Railway

PASSOS:

1) Suba este projeto no GitHub
2) No Railway:
   - New Project
   - Add PostgreSQL
   - Deploy from GitHub
3) Railway cria automaticamente a variável DATABASE_URL
4) Start command: npm start

Depois disso seu sistema estará online com banco e múltiplos usuários.
