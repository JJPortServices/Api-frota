# 🚛 Sistema de Gestão de Frota - Caminhões

Sistema web completo e profissional para gestão de frota de caminhões, focado em controle financeiro, operacional e documental. Desenvolvido para ser 100% responsivo e otimizado para uso em dispositivos móveis.

---

## 📋 Sobre o Projeto

Este sistema foi desenvolvido para gerenciar **2 caminhões que trabalham para terceiros**, oferecendo controle completo de:

- 💰 **Faturamento e Receitas**
- 💸 **Despesas Operacionais**
- 🤝 **Comissões de Motoristas** (% variável por viagem)
- 🛣️ **Viagens e Rotas**
- 🔧 **Manutenções** (preventiva e corretiva)
- 📄 **Documentos** (com alertas de vencimento)
- 📊 **Relatórios Financeiros**

---

## ✨ Funcionalidades Implementadas

### 🏠 Dashboard
- ✅ Visão geral financeira do mês atual
- ✅ Cards com faturamento, lucro líquido, comissões e despesas
- ✅ Alertas de pendências (documentos vencendo, manutenções, pagamentos)
- ✅ Lista de viagens recentes
- ✅ Atualização automática de dados

### 🚛 Gestão de Caminhões
- ✅ Cadastro completo (placa, modelo, ano, cor, RENAVAM, chassi)
- ✅ Controle de quilometragem atual
- ✅ Status (ativo, manutenção, inativo)
- ✅ Visualização em cards informativos
- ✅ Edição e exclusão de registros

### 👤 Gestão de Motoristas
- ✅ Cadastro completo (nome, CPF, telefone, e-mail)
- ✅ Dados da CNH (número, categoria, vencimento)
- ✅ **Percentual de comissão padrão configurável**
- ✅ Status (ativo, inativo)
- ✅ Visualização em cards com informações detalhadas

### 🛣️ Controle de Viagens
- ✅ Cadastro de viagens (data, origem, destino, cliente)
- ✅ Seleção de caminhão e motorista
- ✅ **Cálculo automático de comissão** (% variável por viagem)
- ✅ Valor do frete e comissão calculada automaticamente
- ✅ Controle de KM rodado
- ✅ Número de nota fiscal (quando emitida)
- ✅ **Status de pagamento** (pendente, pago, atrasado)
- ✅ Data de pagamento recebido
- ✅ Filtros por caminhão e status de pagamento
- ✅ Busca por origem, destino ou cliente

### 💳 Controle de Despesas
- ✅ Cadastro de despesas por caminhão
- ✅ **Categorias**: combustível, pedágio, manutenção, pneu, seguro, licenciamento, multa, outros
- ✅ Vinculação com viagens (opcional)
- ✅ Dados do fornecedor e documento fiscal
- ✅ Filtros por caminhão, categoria
- ✅ Busca por descrição ou fornecedor

### 🔧 Controle de Manutenções
- ✅ Cadastro de manutenções por caminhão
- ✅ **Tipos**: preventiva e corretiva
- ✅ Controle de KM realizada e próxima KM
- ✅ Valor e oficina
- ✅ **Status**: pendente, agendada, realizada
- ✅ Histórico completo de manutenções
- ✅ Filtros por caminhão, tipo e status

### 📄 Gestão de Documentos
- ✅ Cadastro de documentos de caminhões e motoristas
- ✅ **Tipos**: CNH, CRLV, seguro, ANTT, IPVA, outros
- ✅ Controle de emissão e vencimento
- ✅ **Atualização automática de status** (válido, vencendo, vencido)
- ✅ **Alertas no Dashboard** para documentos vencendo (30 dias)
- ✅ Filtros por tipo de entidade, tipo de documento e status

### 📊 Relatórios Financeiros
- ✅ Relatórios por mês e caminhão
- ✅ Total de faturamento do período
- ✅ Total de despesas do período
- ✅ Total de comissões pagas
- ✅ **Cálculo de lucro líquido**
- ✅ **Gráfico de despesas por categoria** (pizza)
- ✅ **Gráfico de faturamento por caminhão** (barras)
- ✅ Filtros flexíveis por período e caminhão

---

## 🎯 Funcionalidades Principais em Destaque

### 💰 Cálculo Automático de Comissões
- Cada motorista tem um **percentual de comissão padrão**
- Ao criar uma viagem, o sistema sugere automaticamente a comissão do motorista
- **Possibilidade de alterar o % por viagem** (para fretes especiais)
- Cálculo automático do valor da comissão em reais
- Controle de comissões a pagar no Dashboard

### 📱 Design Responsivo Mobile-First
- Interface otimizada para smartphones
- Menu lateral retrátil em dispositivos móveis
- Cards e tabelas adaptáveis
- Formulários otimizados para toque
- Navegação intuitiva com ícones

### 🔔 Sistema de Alertas Inteligente
- Alertas automáticos de documentos vencendo (30 dias antes)
- Notificações de documentos vencidos
- Alertas de manutenções pendentes
- Avisos de pagamentos pendentes
- Centralizado no Dashboard

---

## 🗂️ Estrutura de Dados

O sistema utiliza 6 tabelas principais:

### 📦 caminhoes
- Placa, modelo, ano, cor
- RENAVAM e chassi
- Quilometragem atual
- Status (ativo, manutenção, inativo)

### 👥 motoristas
- Nome completo, CPF, contatos
- CNH (número, categoria, vencimento)
- **Comissão padrão (%)**
- Status (ativo, inativo)

### 🛣️ viagens
- Data, origem, destino
- Caminhão e motorista
- Cliente e valor do frete
- **% de comissão e valor calculado**
- KM rodado e nota fiscal
- **Status de pagamento e data**

### 💸 despesas
- Data e categoria
- Caminhão vinculado
- Descrição e valor
- Fornecedor e documento fiscal

### 🔧 manutencoes
- Data e tipo (preventiva/corretiva)
- Caminhão vinculado
- KM realizada e próxima KM
- Valor e oficina
- Status (pendente, agendada, realizada)

### 📄 documentos
- Tipo de entidade (caminhão/motorista)
- Tipo de documento (CNH, CRLV, seguro, etc.)
- Número, emissão e vencimento
- **Status automático** (válido, vencendo, vencido)

---

## 🚀 Como Usar

### Acesso Rápido
1. Abra o arquivo `index.html` no navegador
2. No mobile: acesse através do navegador do celular
3. O sistema funciona offline após o primeiro carregamento

### Fluxo de Trabalho Recomendado

#### 1️⃣ Configuração Inicial
1. Acesse **"Caminhões"** e cadastre seus 2 caminhões
2. Acesse **"Motoristas"** e cadastre os motoristas (defina a comissão padrão)
3. Acesse **"Documentos"** e cadastre os documentos de ambos

#### 2️⃣ Uso Diário
1. **Antes da viagem**: Acesse "Viagens" → "Nova Viagem"
2. Preencha origem, destino, cliente e valor
3. O sistema calcula automaticamente a comissão
4. Após a viagem: Registre as despesas (combustível, pedágio, etc.)

#### 3️⃣ Controle Financeiro
1. Acesse o **Dashboard** para visão geral do mês
2. Marque pagamentos recebidos em "Viagens"
3. Gere **Relatórios** mensais para análise detalhada

#### 4️⃣ Manutenção
1. Fique atento aos **alertas de documentos vencendo**
2. Registre manutenções preventivas e corretivas
3. Atualize a quilometragem dos caminhões regularmente

---

## 📱 URIs e Navegação

### Páginas Principais
- `/` ou `/index.html` - Dashboard (página inicial)

### Módulos (navegação interna)
- **Dashboard** - Visão geral e alertas
- **Viagens** - Gestão de viagens e fretes
- **Despesas** - Controle de custos operacionais
- **Caminhões** - Cadastro e gestão de veículos
- **Motoristas** - Cadastro e gestão de motoristas
- **Manutenções** - Histórico e agendamento
- **Documentos** - Controle de documentação
- **Relatórios** - Análises financeiras

### API Endpoints (automático)
O sistema utiliza a RESTful Table API:
- `GET /tables/{table}` - Listar registros
- `GET /tables/{table}/{id}` - Buscar registro específico
- `POST /tables/{table}` - Criar novo registro
- `PUT /tables/{table}/{id}` - Atualizar registro completo
- `PATCH /tables/{table}/{id}` - Atualizar campos específicos
- `DELETE /tables/{table}/{id}` - Excluir registro

---

## 🎨 Tecnologias Utilizadas

### Frontend
- **HTML5** - Estrutura semântica
- **CSS3** - Design moderno com variáveis CSS
- **JavaScript ES6+** - Lógica e interatividade
- **Chart.js** - Gráficos e visualizações
- **Font Awesome** - Ícones
- **Google Fonts (Inter)** - Tipografia

### Backend/Dados
- **RESTful Table API** - Persistência de dados
- **JSON** - Formato de dados
- **Fetch API** - Comunicação com servidor

---

## 📊 Recursos Visuais

### Dashboard
- Cards coloridos com métricas financeiras
- Lista de alertas com ícones e cores
- Tabela de viagens recentes

### Relatórios
- Gráfico de pizza: despesas por categoria
- Gráfico de barras: faturamento por caminhão
- Cards com totalizadores

### Design System
- **Cores primárias**: Azul (#2563eb) para ações principais
- **Status**: Verde (sucesso), Amarelo (alerta), Vermelho (perigo)
- **Tipografia**: Inter (legível e moderna)
- **Espaçamento**: Grid system responsivo

---

## ✅ Funcionalidades Completas

### Implementado ✓
- [x] Dashboard com visão geral financeira
- [x] Gestão completa de caminhões
- [x] Gestão completa de motoristas
- [x] Controle de viagens com comissões variáveis
- [x] Controle de despesas categorizadas
- [x] Controle de manutenções (preventiva/corretiva)
- [x] Gestão de documentos com alertas automáticos
- [x] Relatórios financeiros com gráficos
- [x] Sistema de filtros e buscas
- [x] Design 100% responsivo mobile
- [x] Cálculo automático de lucro líquido
- [x] Alertas de vencimentos
- [x] Interface intuitiva e moderna

---

## 🔮 Próximas Melhorias Sugeridas

### Funcionalidades Futuras
- [ ] Sistema de backup e exportação de dados
- [ ] Notificações push para alertas
- [ ] Integração com GPS para tracking de viagens
- [ ] Cálculo de custo por km
- [ ] Previsão de manutenções baseada em km
- [ ] Dashboard com gráficos de tendências
- [ ] Exportação de relatórios em PDF
- [ ] Sistema de login multiusuário
- [ ] Histórico de alterações (auditoria)
- [ ] Integração com contador (XML de NF-e)

### Melhorias Técnicas
- [ ] Service Worker para funcionamento offline completo
- [ ] Progressive Web App (PWA)
- [ ] Sincronização automática de dados
- [ ] Compressão de dados para performance
- [ ] Temas escuro/claro

---

## 📖 Guia Rápido de Uso

### Para Cadastrar uma Viagem
1. Menu → **Viagens** → **Nova Viagem**
2. Selecione data, caminhão e motorista
3. Informe origem, destino e cliente
4. Digite o valor do frete
5. A comissão é calculada automaticamente
6. Ajuste a % se necessário
7. Clique em **Salvar**

### Para Registrar uma Despesa
1. Menu → **Despesas** → **Nova Despesa**
2. Selecione data e caminhão
3. Escolha a categoria
4. Digite descrição e valor
5. Informe fornecedor (opcional)
6. Clique em **Salvar**

### Para Gerar Relatório
1. Menu → **Relatórios**
2. Selecione o mês
3. Escolha um caminhão específico ou "Todos"
4. Clique em **Gerar Relatório**
5. Visualize os gráficos e totalizadores

---

## 💡 Dicas de Uso

### Organização
- Cadastre as despesas logo após ocorrerem
- Atualize o status de pagamento assim que receber
- Mantenha a quilometragem dos caminhões atualizada
- Cadastre documentos assim que renovados

### Controle Financeiro
- Gere relatórios mensais para análise
- Compare o lucro entre os caminhões
- Identifique as categorias de despesas mais altas
- Acompanhe o Dashboard diariamente

### Manutenção
- Configure manutenções preventivas com antecedência
- Use o campo "Próxima KM" para planejamento
- Registre todas as manutenções para histórico
- Fique atento aos alertas do Dashboard

---

## 🎯 Benefícios do Sistema

✅ **Controle Total**: Visão completa de custos e receitas  
✅ **Mobilidade**: Acesse de qualquer dispositivo móvel  
✅ **Automação**: Cálculos automáticos de comissões e lucros  
✅ **Alertas**: Nunca perca prazos de documentos  
✅ **Organização**: Todos os dados centralizados  
✅ **Decisão**: Relatórios para tomada de decisão  
✅ **Economia**: Identifique custos desnecessários  
✅ **Profissionalismo**: Gestão empresarial eficiente  

---

## 📞 Suporte

Para dúvidas ou sugestões sobre o sistema:
- Acesse a documentação completa neste arquivo
- Revise os exemplos de uso acima
- Teste cada funcionalidade no ambiente de desenvolvimento

---

## 📄 Licença

Sistema desenvolvido para gestão pessoal de frota de caminhões.

---

**Desenvolvido com ❤️ para gestão eficiente de frotas**

🚛 **Gestão de Frota** - Controle completo na palma da sua mão!
