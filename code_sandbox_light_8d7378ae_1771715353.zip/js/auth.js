// ========================================
// SISTEMA DE AUTENTICAÇÃO - Gestão de Frota
// ========================================

// -------------------------------------------------------
// 🔐 USUÁRIOS E SENHAS — altere aqui para personalizar
// -------------------------------------------------------
const USERS = [
    { user: 'admin',    pass: 'frota2024',  nome: 'Administrador' },
    { user: 'motorista1', pass: 'moto123',  nome: 'Motorista 1'   },
    { user: 'motorista2', pass: 'moto456',  nome: 'Motorista 2'   },
];
// -------------------------------------------------------

const SESSION_KEY = 'frota_auth_session';
const SESSION_DURATION_MS = 8 * 60 * 60 * 1000; // 8 horas

const Auth = {
    init() {
        // Verifica se já está autenticado
        if (this.isAuthenticated()) {
            this.showApp();
        } else {
            this.showLogin();
        }
        this.setupLoginForm();
    },

    // Verifica sessão válida no sessionStorage
    isAuthenticated() {
        try {
            const raw = sessionStorage.getItem(SESSION_KEY);
            if (!raw) return false;
            const session = JSON.parse(raw);
            const agora = Date.now();
            if (agora - session.loginTime > SESSION_DURATION_MS) {
                sessionStorage.removeItem(SESSION_KEY);
                return false;
            }
            return true;
        } catch {
            return false;
        }
    },

    getSession() {
        try {
            return JSON.parse(sessionStorage.getItem(SESSION_KEY));
        } catch {
            return null;
        }
    },

    login(user, pass) {
        const found = USERS.find(
            u => u.user.toLowerCase() === user.trim().toLowerCase() &&
                 u.pass === pass
        );
        if (found) {
            sessionStorage.setItem(SESSION_KEY, JSON.stringify({
                user: found.user,
                nome: found.nome,
                loginTime: Date.now()
            }));
            return found;
        }
        return null;
    },

    logout() {
        sessionStorage.removeItem(SESSION_KEY);
        location.reload();
    },

    showLogin() {
        document.body.classList.add('not-authenticated');
        const screen = document.getElementById('loginScreen');
        if (screen) screen.classList.remove('hidden');
    },

    showApp() {
        document.body.classList.remove('not-authenticated');
        const screen = document.getElementById('loginScreen');
        if (screen) screen.classList.add('hidden');

        // Mostra nome do usuário logado no header
        const session = this.getSession();
        if (session) {
            this.addUserBadge(session.nome);
        }
    },

    // Adiciona badge do usuário + botão sair no header
    addUserBadge(nome) {
        const headerContent = document.querySelector('.header-content');
        if (!headerContent || document.getElementById('userBadge')) return;

        const badge = document.createElement('div');
        badge.id = 'userBadge';
        badge.style.cssText = `
            display: flex; align-items: center; gap: 0.5rem;
            font-size: 0.8rem; color: #64748b; cursor: pointer;
        `;
        badge.innerHTML = `
            <i class="fas fa-user-circle" style="font-size:1.4rem; color:#2563eb;"></i>
            <span style="display:none;" id="userName">${nome}</span>
            <button id="logoutBtn" title="Sair" style="
                background: transparent; border: none; cursor: pointer;
                color: #ef4444; font-size: 1rem; padding: 0.25rem;
                display: flex; align-items: center; gap: 0.25rem;
            ">
                <i class="fas fa-sign-out-alt"></i>
            </button>
        `;

        // Mostrar nome ao passar o mouse (desktop)
        badge.addEventListener('mouseenter', () => {
            document.getElementById('userName').style.display = 'inline';
        });
        badge.addEventListener('mouseleave', () => {
            document.getElementById('userName').style.display = 'none';
        });

        // Botão sair
        badge.querySelector('#logoutBtn').addEventListener('click', () => {
            if (confirm('Deseja sair do sistema?')) {
                Auth.logout();
            }
        });

        // Inserir antes do botão de menu
        const menuToggle = document.getElementById('menuToggle');
        if (menuToggle) {
            headerContent.insertBefore(badge, menuToggle);
        } else {
            headerContent.appendChild(badge);
        }
    },

    setupLoginForm() {
        const form = document.getElementById('loginForm');
        const loginBtn = document.getElementById('loginBtn');
        const loginError = document.getElementById('loginError');
        const togglePass = document.getElementById('togglePass');
        const passInput = document.getElementById('loginPass');

        // Mostrar/Ocultar senha
        togglePass?.addEventListener('click', () => {
            const isPassword = passInput.type === 'password';
            passInput.type = isPassword ? 'text' : 'password';
            togglePass.querySelector('i').className = isPassword
                ? 'fas fa-eye-slash'
                : 'fas fa-eye';
        });

        // Submit do formulário
        form?.addEventListener('submit', () => this.handleLogin());
        loginBtn?.addEventListener('click', () => this.handleLogin());

        // Enter no campo de senha
        passInput?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') this.handleLogin();
        });
    },

    handleLogin() {
        const loginError = document.getElementById('loginError');
        const loginBtn = document.getElementById('loginBtn');
        const user = document.getElementById('loginUser')?.value || '';
        const pass = document.getElementById('loginPass')?.value || '';

        if (!user || !pass) {
            loginError.textContent = '⚠️ Preencha usuário e senha!';
            loginError.style.display = 'flex';
            return;
        }

        // Animação de carregamento
        loginBtn.disabled = true;
        loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verificando...';

        setTimeout(() => {
            const result = this.login(user, pass);

            if (result) {
                loginBtn.innerHTML = '<i class="fas fa-check"></i> Bem-vindo, ' + result.nome + '!';
                loginBtn.style.background = 'linear-gradient(135deg, #10b981, #059669)';
                loginError.style.display = 'none';
                setTimeout(() => {
                    this.showApp();
                    // Inicializa o app principal após login
                    if (typeof App !== 'undefined') {
                        App.init();
                    }
                }, 600);
            } else {
                loginError.innerHTML = '<i class="fas fa-exclamation-circle"></i> Usuário ou senha incorretos!';
                loginError.style.display = 'flex';
                loginBtn.disabled = false;
                loginBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Entrar';
                document.getElementById('loginPass').value = '';
                document.getElementById('loginPass').focus();
            }
        }, 500);
    }
};

// Inicializa autenticação quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    // Inicia body como não autenticado até verificar
    document.body.classList.add('not-authenticated');
    Auth.init();
});
