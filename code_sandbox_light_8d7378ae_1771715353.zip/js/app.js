// ========================================
// GESTÃO DE FROTA - Sistema de Caminhões
// ========================================

// Estado Global da Aplicação
const App = {
    state: {
        currentView: 'dashboard',
        caminhoes: [],
        motoristas: [],
        viagens: [],
        despesas: [],
        manutencoes: [],
        documentos: []
    },
    init() {
        this.setupEventListeners();
        this.loadAllData();
        this.showView('dashboard');
    },

    // Configurar Event Listeners
    setupEventListeners() {
        // Menu Toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        menuToggle?.addEventListener('click', () => {
            sidebar.classList.toggle('active');
        });

        // Fechar sidebar ao clicar fora (mobile)
        document.addEventListener('click', (e) => {
            if (window.innerWidth < 768) {
                if (!e.target.closest('.sidebar') && !e.target.closest('.menu-toggle')) {
                    sidebar.classList.remove('active');
                }
            }
        });

        // Navegação
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', () => {
                const view = item.dataset.view;
                this.showView(view);
                
                // Fechar sidebar no mobile
                if (window.innerWidth < 768) {
                    sidebar.classList.remove('active');
                }
            });
        });

        // Modal
        const modal = document.getElementById('modal');
        const modalClose = document.getElementById('modalClose');
        modalClose?.addEventListener('click', () => this.closeModal());
        modal?.addEventListener('click', (e) => {
            if (e.target === modal) this.closeModal();
        });

        // Botões de ação
        document.getElementById('btnNovoCaminhao')?.addEventListener('click', () => this.showCaminhaoForm());
        document.getElementById('btnNovoMotorista')?.addEventListener('click', () => this.showMotoristaForm());
        document.getElementById('btnNovaViagem')?.addEventListener('click', () => this.showViagemForm());
        document.getElementById('btnNovaDespesa')?.addEventListener('click', () => this.showDespesaForm());
        document.getElementById('btnNovaManutencao')?.addEventListener('click', () => this.showManutencaoForm());
        document.getElementById('btnNovoDocumento')?.addEventListener('click', () => this.showDocumentoForm());
        document.getElementById('btnGerarRelatorio')?.addEventListener('click', () => this.gerarRelatorio());

        // Filtros
        this.setupFilters();
    },

    // Configurar Filtros
    setupFilters() {
        // Filtros de Viagens
        ['filtroViagens', 'filtroCaminhaoViagem', 'filtroStatusPagamento'].forEach(id => {
            document.getElementById(id)?.addEventListener('input', () => this.filterViagens());
        });

        // Filtros de Despesas
        ['filtroDespesas', 'filtroCaminhaoDespesa', 'filtroCategoriaDespesa'].forEach(id => {
            document.getElementById(id)?.addEventListener('input', () => this.filterDespesas());
        });

        // Filtros de Manutenções
        ['filtroCaminhaoManutencao', 'filtroTipoManutencao', 'filtroStatusManutencao'].forEach(id => {
            document.getElementById(id)?.addEventListener('input', () => this.filterManutencoes());
        });

        // Filtros de Documentos
        ['filtroTipoEntidade', 'filtroTipoDocumento', 'filtroStatusDocumento'].forEach(id => {
            document.getElementById(id)?.addEventListener('input', () => this.filterDocumentos());
        });
    },

    // Navegação entre Views
    showView(viewName) {
        // Atualizar navegação
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
            if (item.dataset.view === viewName) {
                item.classList.add('active');
            }
        });

        // Atualizar views
        document.querySelectorAll('.view-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(`${viewName}-view`)?.classList.add('active');

        this.state.currentView = viewName;

        // Carregar dados específicos da view
        switch(viewName) {
            case 'dashboard':
                this.loadDashboard();
                break;
            case 'viagens':
                this.loadViagens();
                break;
            case 'despesas':
                this.loadDespesas();
                break;
            case 'caminhoes':
                this.loadCaminhoes();
                break;
            case 'motoristas':
                this.loadMotoristas();
                break;
            case 'manutencoes':
                this.loadManutencoes();
                break;
            case 'documentos':
                this.loadDocumentos();
                break;
            case 'relatorios':
                this.initRelatorios();
                break;
        }
    },

    // Modal
    showModal(title, content) {
        document.getElementById('modalTitle').textContent = title;
        document.getElementById('modalBody').innerHTML = content;
        document.getElementById('modal').classList.add('active');
    },

    closeModal() {
        document.getElementById('modal').classList.remove('active');
    },

    // Loading
    showLoading() {
        document.getElementById('loadingOverlay')?.classList.add('active');
    },

    hideLoading() {
        document.getElementById('loadingOverlay')?.classList.remove('active');
    },

    // ========================================
    // API - Integração com Banco de Dados
    // ========================================

    async api(endpoint, options = {}) {
        try {
            const response = await fetch(endpoint, {
                ...options,
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            alert('Erro ao comunicar com o servidor. Tente novamente.');
            throw error;
        }
    },

    // Carregar todos os dados iniciais
    async loadAllData() {
        this.showLoading();
        try {
            const [caminhoes, motoristas, viagens, despesas, manutencoes, documentos] = await Promise.all([
                this.api('tables/caminhoes?limit=100'),
                this.api('tables/motoristas?limit=100'),
                this.api('tables/viagens?limit=100'),
                this.api('tables/despesas?limit=100'),
                this.api('tables/manutencoes?limit=100'),
                this.api('tables/documentos?limit=100')
            ]);

            this.state.caminhoes = caminhoes.data || [];
            this.state.motoristas = motoristas.data || [];
            this.state.viagens = viagens.data || [];
            this.state.despesas = despesas.data || [];
            this.state.manutencoes = manutencoes.data || [];
            this.state.documentos = documentos.data || [];

            this.populateFilters();
        } catch (error) {
            console.error('Error loading data:', error);
        } finally {
            this.hideLoading();
        }
    },

    // Popular filtros com dados
    populateFilters() {
        const caminhaoSelects = [
            'filtroCaminhaoViagem',
            'filtroCaminhaoDespesa',
            'filtroCaminhaoManutencao',
            'filtroCaminhaoRelatorio'
        ];

        caminhaoSelects.forEach(selectId => {
            const select = document.getElementById(selectId);
            if (select) {
                const currentValue = select.value;
                select.innerHTML = '<option value="">Todos os caminhões</option>';
                this.state.caminhoes.forEach(caminhao => {
                    const option = document.createElement('option');
                    option.value = caminhao.id;
                    option.textContent = `${caminhao.placa} - ${caminhao.modelo}`;
                    select.appendChild(option);
                });
                select.value = currentValue;
            }
        });
    },

    // ========================================
    // DASHBOARD
    // ========================================

    async loadDashboard() {
        this.showLoading();
        try {
            await this.loadAllData();
            
            const hoje = new Date();
            const primeiroDiaMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
            
            // Calcular faturamento do mês
            const viagensMes = this.state.viagens.filter(v => {
                const dataViagem = new Date(v.data_viagem);
                return dataViagem >= primeiroDiaMes;
            });
            
            const faturamentoMes = viagensMes.reduce((sum, v) => sum + (v.valor_frete || 0), 0);
            
            // Calcular despesas do mês
            const despesasMes = this.state.despesas.filter(d => {
                const dataDespesa = new Date(d.data_despesa);
                return dataDespesa >= primeiroDiaMes;
            }).reduce((sum, d) => sum + (d.valor || 0), 0);
            
            // Calcular comissões do mês
            const comissoesMes = viagensMes.reduce((sum, v) => sum + (v.valor_comissao || 0), 0);
            
            // Calcular lucro líquido
            const lucroLiquido = faturamentoMes - despesasMes - comissoesMes;
            
            // Atualizar cards
            document.getElementById('faturamentoMes').textContent = this.formatCurrency(faturamentoMes);
            document.getElementById('lucroLiquido').textContent = this.formatCurrency(lucroLiquido);
            document.getElementById('comissoesPagar').textContent = this.formatCurrency(comissoesMes);
            document.getElementById('despesasMes').textContent = this.formatCurrency(despesasMes);
            
            // Carregar alertas
            this.loadAlertas();
            
            // Carregar viagens recentes
            this.loadViagensRecentes();
            
        } finally {
            this.hideLoading();
        }
    },

    loadAlertas() {
        const alertasList = document.getElementById('alertasList');
        const alertas = [];
        
        const hoje = new Date();
        const proximosMeses = new Date(hoje);
        proximosMeses.setMonth(hoje.getMonth() + 1);
        
        // Verificar documentos vencidos ou vencendo
        this.state.documentos.forEach(doc => {
            const vencimento = new Date(doc.data_vencimento);
            if (vencimento < hoje) {
                alertas.push({
                    type: 'danger',
                    message: `Documento ${doc.tipo_documento} vencido (${doc.numero_documento})`
                });
            } else if (vencimento < proximosMeses) {
                alertas.push({
                    type: 'warning',
                    message: `Documento ${doc.tipo_documento} vencendo em breve (${doc.numero_documento})`
                });
            }
        });
        
        // Verificar manutenções pendentes
        this.state.manutencoes.filter(m => m.status === 'pendente').forEach(manutencao => {
            const caminhao = this.state.caminhoes.find(c => c.id === manutencao.caminhao_id);
            if (caminhao) {
                alertas.push({
                    type: 'warning',
                    message: `Manutenção pendente para ${caminhao.placa}`
                });
            }
        });
        
        // Verificar pagamentos pendentes
        const viagensPendentes = this.state.viagens.filter(v => v.status_pagamento === 'pendente');
        if (viagensPendentes.length > 0) {
            const totalPendente = viagensPendentes.reduce((sum, v) => sum + (v.valor_frete || 0), 0);
            alertas.push({
                type: 'warning',
                message: `${viagensPendentes.length} viagens com pagamento pendente (Total: ${this.formatCurrency(totalPendente)})`
            });
        }
        
        if (alertas.length === 0) {
            alertasList.innerHTML = '<p class="no-data">Nenhum alerta no momento 😊</p>';
        } else {
            alertasList.innerHTML = alertas.map(a => `
                <div class="alert-item alert-${a.type}">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>${a.message}</span>
                </div>
            `).join('');
        }
    },

    loadViagensRecentes() {
        const container = document.getElementById('viagensRecentes');
        const viagensRecentes = [...this.state.viagens]
            .sort((a, b) => new Date(b.data_viagem) - new Date(a.data_viagem))
            .slice(0, 5);
        
        if (viagensRecentes.length === 0) {
            container.innerHTML = '<p class="no-data">Nenhuma viagem cadastrada</p>';
            return;
        }
        
        const html = `
            <table>
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Origem → Destino</th>
                        <th>Caminhão</th>
                        <th>Valor</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    ${viagensRecentes.map(v => {
                        const caminhao = this.state.caminhoes.find(c => c.id === v.caminhao_id);
                        return `
                            <tr>
                                <td>${this.formatDate(v.data_viagem)}</td>
                                <td>${v.origem} → ${v.destino}</td>
                                <td>${caminhao?.placa || '-'}</td>
                                <td>${this.formatCurrency(v.valor_frete)}</td>
                                <td>${this.getStatusBadge(v.status_pagamento)}</td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;
        
        container.innerHTML = html;
    },

    // ========================================
    // CAMINHÕES
    // ========================================

    async loadCaminhoes() {
        this.showLoading();
        try {
            const data = await this.api('tables/caminhoes?limit=100');
            this.state.caminhoes = data.data || [];
            this.renderCaminhoes();
        } finally {
            this.hideLoading();
        }
    },

    renderCaminhoes() {
        const container = document.getElementById('caminhoesList');
        
        if (this.state.caminhoes.length === 0) {
            container.innerHTML = '<p class="no-data">Nenhum caminhão cadastrado. Clique em "Novo Caminhão" para começar.</p>';
            return;
        }
        
        const html = this.state.caminhoes.map(caminhao => `
            <div class="item-card">
                <div class="item-card-header">
                    <div>
                        <div class="item-card-title">${caminhao.placa}</div>
                        <div class="item-card-subtitle">${caminhao.modelo} - ${caminhao.ano}</div>
                    </div>
                    <span class="badge badge-${caminhao.status === 'ativo' ? 'success' : caminhao.status === 'manutenção' ? 'warning' : 'secondary'}">
                        ${caminhao.status}
                    </span>
                </div>
                <div class="item-card-body">
                    <div class="item-card-info">
                        <i class="fas fa-palette"></i>
                        <span>${caminhao.cor}</span>
                    </div>
                    <div class="item-card-info">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>${this.formatNumber(caminhao.km_atual)} km</span>
                    </div>
                    <div class="item-card-info">
                        <i class="fas fa-id-card"></i>
                        <span>RENAVAM: ${caminhao.renavam}</span>
                    </div>
                </div>
                <div class="item-card-actions">
                    <button class="btn btn-primary btn-small" onclick="App.editCaminhao('${caminhao.id}')">
                        <i class="fas fa-edit"></i> Editar
                    </button>
                    <button class="btn btn-danger btn-small" onclick="App.deleteCaminhao('${caminhao.id}')">
                        <i class="fas fa-trash"></i> Excluir
                    </button>
                </div>
            </div>
        `).join('');
        
        container.innerHTML = html;
    },

    showCaminhaoForm(caminhao = null) {
        const isEdit = caminhao !== null;
        const title = isEdit ? 'Editar Caminhão' : 'Novo Caminhão';
        
        const content = `
            <form id="caminhaoForm">
                <div class="form-row">
                    <div class="form-group">
                        <label>Placa *</label>
                        <input type="text" name="placa" value="${caminhao?.placa || ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Modelo *</label>
                        <input type="text" name="modelo" value="${caminhao?.modelo || ''}" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Ano *</label>
                        <input type="number" name="ano" value="${caminhao?.ano || ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Cor</label>
                        <input type="text" name="cor" value="${caminhao?.cor || ''}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>RENAVAM</label>
                        <input type="text" name="renavam" value="${caminhao?.renavam || ''}">
                    </div>
                    <div class="form-group">
                        <label>Chassi</label>
                        <input type="text" name="chassi" value="${caminhao?.chassi || ''}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>KM Atual *</label>
                        <input type="number" name="km_atual" value="${caminhao?.km_atual || 0}" required>
                    </div>
                    <div class="form-group">
                        <label>Status *</label>
                        <select name="status" required>
                            <option value="ativo" ${caminhao?.status === 'ativo' ? 'selected' : ''}>Ativo</option>
                            <option value="manutenção" ${caminhao?.status === 'manutenção' ? 'selected' : ''}>Manutenção</option>
                            <option value="inativo" ${caminhao?.status === 'inativo' ? 'selected' : ''}>Inativo</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Observações</label>
                    <textarea name="observacoes">${caminhao?.observacoes || ''}</textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="App.closeModal()">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar
                    </button>
                </div>
            </form>
        `;
        
        this.showModal(title, content);
        
        document.getElementById('caminhaoForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            this.showLoading();
            try {
                if (isEdit) {
                    await this.api(`tables/caminhoes/${caminhao.id}`, {
                        method: 'PUT',
                        body: JSON.stringify(data)
                    });
                } else {
                    await this.api('tables/caminhoes', {
                        method: 'POST',
                        body: JSON.stringify(data)
                    });
                }
                
                this.closeModal();
                await this.loadCaminhoes();
                await this.populateFilters();
                alert(isEdit ? 'Caminhão atualizado com sucesso!' : 'Caminhão cadastrado com sucesso!');
            } finally {
                this.hideLoading();
            }
        });
    },

    async editCaminhao(id) {
        const caminhao = this.state.caminhoes.find(c => c.id === id);
        if (caminhao) {
            this.showCaminhaoForm(caminhao);
        }
    },

    async deleteCaminhao(id) {
        if (!confirm('Tem certeza que deseja excluir este caminhão?')) return;
        
        this.showLoading();
        try {
            await this.api(`tables/caminhoes/${id}`, { method: 'DELETE' });
            await this.loadCaminhoes();
            await this.populateFilters();
            alert('Caminhão excluído com sucesso!');
        } finally {
            this.hideLoading();
        }
    },

    // ========================================
    // MOTORISTAS
    // ========================================

    async loadMotoristas() {
        this.showLoading();
        try {
            const data = await this.api('tables/motoristas?limit=100');
            this.state.motoristas = data.data || [];
            this.renderMotoristas();
        } finally {
            this.hideLoading();
        }
    },

    renderMotoristas() {
        const container = document.getElementById('motoristasList');
        
        if (this.state.motoristas.length === 0) {
            container.innerHTML = '<p class="no-data">Nenhum motorista cadastrado. Clique em "Novo Motorista" para começar.</p>';
            return;
        }
        
        const html = this.state.motoristas.map(motorista => `
            <div class="item-card">
                <div class="item-card-header">
                    <div>
                        <div class="item-card-title">${motorista.nome}</div>
                        <div class="item-card-subtitle">CPF: ${motorista.cpf}</div>
                    </div>
                    <span class="badge badge-${motorista.status === 'ativo' ? 'success' : 'secondary'}">
                        ${motorista.status}
                    </span>
                </div>
                <div class="item-card-body">
                    <div class="item-card-info">
                        <i class="fas fa-phone"></i>
                        <span>${motorista.telefone || '-'}</span>
                    </div>
                    <div class="item-card-info">
                        <i class="fas fa-id-card"></i>
                        <span>CNH: ${motorista.cnh} (${motorista.categoria_cnh})</span>
                    </div>
                    <div class="item-card-info">
                        <i class="fas fa-percentage"></i>
                        <span>Comissão padrão: ${motorista.comissao_padrao}%</span>
                    </div>
                    <div class="item-card-info">
                        <i class="fas fa-calendar"></i>
                        <span>CNH vence em: ${this.formatDate(motorista.vencimento_cnh)}</span>
                    </div>
                </div>
                <div class="item-card-actions">
                    <button class="btn btn-primary btn-small" onclick="App.editMotorista('${motorista.id}')">
                        <i class="fas fa-edit"></i> Editar
                    </button>
                    <button class="btn btn-danger btn-small" onclick="App.deleteMotorista('${motorista.id}')">
                        <i class="fas fa-trash"></i> Excluir
                    </button>
                </div>
            </div>
        `).join('');
        
        container.innerHTML = html;
    },

    showMotoristaForm(motorista = null) {
        const isEdit = motorista !== null;
        const title = isEdit ? 'Editar Motorista' : 'Novo Motorista';
        
        const content = `
            <form id="motoristaForm">
                <div class="form-group">
                    <label>Nome Completo *</label>
                    <input type="text" name="nome" value="${motorista?.nome || ''}" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>CPF *</label>
                        <input type="text" name="cpf" value="${motorista?.cpf || ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Telefone</label>
                        <input type="tel" name="telefone" value="${motorista?.telefone || ''}">
                    </div>
                </div>
                <div class="form-group">
                    <label>E-mail</label>
                    <input type="email" name="email" value="${motorista?.email || ''}">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>CNH *</label>
                        <input type="text" name="cnh" value="${motorista?.cnh || ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Categoria CNH *</label>
                        <input type="text" name="categoria_cnh" value="${motorista?.categoria_cnh || ''}" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Vencimento CNH *</label>
                        <input type="date" name="vencimento_cnh" value="${motorista?.vencimento_cnh ? new Date(motorista.vencimento_cnh).toISOString().split('T')[0] : ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Comissão Padrão (%) *</label>
                        <input type="number" step="0.01" name="comissao_padrao" value="${motorista?.comissao_padrao || 0}" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Status *</label>
                    <select name="status" required>
                        <option value="ativo" ${motorista?.status === 'ativo' ? 'selected' : ''}>Ativo</option>
                        <option value="inativo" ${motorista?.status === 'inativo' ? 'selected' : ''}>Inativo</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Observações</label>
                    <textarea name="observacoes">${motorista?.observacoes || ''}</textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="App.closeModal()">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar
                    </button>
                </div>
            </form>
        `;
        
        this.showModal(title, content);
        
        document.getElementById('motoristaForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            this.showLoading();
            try {
                if (isEdit) {
                    await this.api(`tables/motoristas/${motorista.id}`, {
                        method: 'PUT',
                        body: JSON.stringify(data)
                    });
                } else {
                    await this.api('tables/motoristas', {
                        method: 'POST',
                        body: JSON.stringify(data)
                    });
                }
                
                this.closeModal();
                await this.loadMotoristas();
                alert(isEdit ? 'Motorista atualizado com sucesso!' : 'Motorista cadastrado com sucesso!');
            } finally {
                this.hideLoading();
            }
        });
    },

    async editMotorista(id) {
        const motorista = this.state.motoristas.find(m => m.id === id);
        if (motorista) {
            this.showMotoristaForm(motorista);
        }
    },

    async deleteMotorista(id) {
        if (!confirm('Tem certeza que deseja excluir este motorista?')) return;
        
        this.showLoading();
        try {
            await this.api(`tables/motoristas/${id}`, { method: 'DELETE' });
            await this.loadMotoristas();
            alert('Motorista excluído com sucesso!');
        } finally {
            this.hideLoading();
        }
    },

    // ========================================
    // VIAGENS
    // ========================================

    async loadViagens() {
        this.showLoading();
        try {
            const data = await this.api('tables/viagens?limit=100&sort=-data_viagem');
            this.state.viagens = data.data || [];
            this.renderViagens();
        } finally {
            this.hideLoading();
        }
    },

    renderViagens(viagens = null) {
        const container = document.getElementById('viagensList');
        const viagensToRender = viagens || this.state.viagens;
        
        if (viagensToRender.length === 0) {
            container.innerHTML = '<p class="no-data">Nenhuma viagem encontrada</p>';
            return;
        }
        
        const html = `
            <table>
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Rota</th>
                        <th>Caminhão</th>
                        <th>Motorista</th>
                        <th>Cliente</th>
                        <th>Valor Frete</th>
                        <th>Comissão</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${viagensToRender.map(viagem => {
                        const caminhao = this.state.caminhoes.find(c => c.id === viagem.caminhao_id);
                        const motorista = this.state.motoristas.find(m => m.id === viagem.motorista_id);
                        return `
                            <tr>
                                <td>${this.formatDate(viagem.data_viagem)}</td>
                                <td>${viagem.origem} → ${viagem.destino}</td>
                                <td>${caminhao?.placa || '-'}</td>
                                <td>${motorista?.nome || '-'}</td>
                                <td>${viagem.cliente}</td>
                                <td>${this.formatCurrency(viagem.valor_frete)}</td>
                                <td>${this.formatCurrency(viagem.valor_comissao)} (${viagem.comissao_percent}%)</td>
                                <td>${this.getStatusBadge(viagem.status_pagamento)}</td>
                                <td>
                                    <button class="btn btn-primary btn-small" onclick="App.editViagem('${viagem.id}')">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-danger btn-small" onclick="App.deleteViagem('${viagem.id}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;
        
        container.innerHTML = html;
    },

    filterViagens() {
        const searchTerm = document.getElementById('filtroViagens')?.value.toLowerCase() || '';
        const caminhaoId = document.getElementById('filtroCaminhaoViagem')?.value || '';
        const statusPagamento = document.getElementById('filtroStatusPagamento')?.value || '';
        
        const filtered = this.state.viagens.filter(viagem => {
            const matchSearch = !searchTerm || 
                viagem.origem.toLowerCase().includes(searchTerm) ||
                viagem.destino.toLowerCase().includes(searchTerm) ||
                viagem.cliente.toLowerCase().includes(searchTerm);
            
            const matchCaminhao = !caminhaoId || viagem.caminhao_id === caminhaoId;
            const matchStatus = !statusPagamento || viagem.status_pagamento === statusPagamento;
            
            return matchSearch && matchCaminhao && matchStatus;
        });
        
        this.renderViagens(filtered);
    },

    showViagemForm(viagem = null) {
        const isEdit = viagem !== null;
        const title = isEdit ? 'Editar Viagem' : 'Nova Viagem';
        
        const motoristaOptions = this.state.motoristas
            .filter(m => m.status === 'ativo')
            .map(m => `<option value="${m.id}" ${viagem?.motorista_id === m.id ? 'selected' : ''}>${m.nome}</option>`)
            .join('');
        
        const caminhaoOptions = this.state.caminhoes
            .filter(c => c.status === 'ativo')
            .map(c => `<option value="${c.id}" ${viagem?.caminhao_id === c.id ? 'selected' : ''}>${c.placa} - ${c.modelo}</option>`)
            .join('');
        
        const content = `
            <form id="viagemForm">
                <div class="form-row">
                    <div class="form-group">
                        <label>Data da Viagem *</label>
                        <input type="date" name="data_viagem" value="${viagem?.data_viagem ? new Date(viagem.data_viagem).toISOString().split('T')[0] : ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Caminhão *</label>
                        <select name="caminhao_id" required>
                            <option value="">Selecione...</option>
                            ${caminhaoOptions}
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Motorista *</label>
                    <select name="motorista_id" id="motoristaSelect" required>
                        <option value="">Selecione...</option>
                        ${motoristaOptions}
                    </select>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Origem *</label>
                        <input type="text" name="origem" value="${viagem?.origem || ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Destino *</label>
                        <input type="text" name="destino" value="${viagem?.destino || ''}" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Cliente *</label>
                    <input type="text" name="cliente" value="${viagem?.cliente || ''}" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Valor do Frete (R$) *</label>
                        <input type="number" step="0.01" name="valor_frete" id="valorFrete" value="${viagem?.valor_frete || ''}" required>
                    </div>
                    <div class="form-group">
                        <label>% Comissão *</label>
                        <input type="number" step="0.01" name="comissao_percent" id="comissaoPercent" value="${viagem?.comissao_percent || ''}" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Valor da Comissão (R$)</label>
                        <input type="number" step="0.01" name="valor_comissao" id="valorComissao" value="${viagem?.valor_comissao || ''}" readonly>
                    </div>
                    <div class="form-group">
                        <label>KM Rodado</label>
                        <input type="number" name="km_rodado" value="${viagem?.km_rodado || ''}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Nota Fiscal</label>
                        <input type="text" name="nota_fiscal" value="${viagem?.nota_fiscal || ''}">
                    </div>
                    <div class="form-group">
                        <label>Status do Pagamento *</label>
                        <select name="status_pagamento" required>
                            <option value="pendente" ${viagem?.status_pagamento === 'pendente' ? 'selected' : ''}>Pendente</option>
                            <option value="pago" ${viagem?.status_pagamento === 'pago' ? 'selected' : ''}>Pago</option>
                            <option value="atrasado" ${viagem?.status_pagamento === 'atrasado' ? 'selected' : ''}>Atrasado</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Data do Pagamento</label>
                    <input type="date" name="data_pagamento" value="${viagem?.data_pagamento ? new Date(viagem.data_pagamento).toISOString().split('T')[0] : ''}">
                </div>
                <div class="form-group">
                    <label>Observações</label>
                    <textarea name="observacoes">${viagem?.observacoes || ''}</textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="App.closeModal()">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar
                    </button>
                </div>
            </form>
        `;
        
        this.showModal(title, content);
        
        // Calcular comissão automaticamente
        const valorFrete = document.getElementById('valorFrete');
        const comissaoPercent = document.getElementById('comissaoPercent');
        const valorComissao = document.getElementById('valorComissao');
        const motoristaSelect = document.getElementById('motoristaSelect');
        
        // Preencher comissão padrão quando selecionar motorista
        motoristaSelect?.addEventListener('change', (e) => {
            const motorista = this.state.motoristas.find(m => m.id === e.target.value);
            if (motorista && !comissaoPercent.value) {
                comissaoPercent.value = motorista.comissao_padrao;
                calcularComissao();
            }
        });
        
        const calcularComissao = () => {
            const frete = parseFloat(valorFrete.value) || 0;
            const percent = parseFloat(comissaoPercent.value) || 0;
            valorComissao.value = (frete * percent / 100).toFixed(2);
        };
        
        valorFrete?.addEventListener('input', calcularComissao);
        comissaoPercent?.addEventListener('input', calcularComissao);
        
        // Calcular comissão inicial se for edição
        if (isEdit) {
            calcularComissao();
        }
        
        document.getElementById('viagemForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            this.showLoading();
            try {
                if (isEdit) {
                    await this.api(`tables/viagens/${viagem.id}`, {
                        method: 'PUT',
                        body: JSON.stringify(data)
                    });
                } else {
                    await this.api('tables/viagens', {
                        method: 'POST',
                        body: JSON.stringify(data)
                    });
                }
                
                this.closeModal();
                await this.loadViagens();
                alert(isEdit ? 'Viagem atualizada com sucesso!' : 'Viagem cadastrada com sucesso!');
            } finally {
                this.hideLoading();
            }
        });
    },

    async editViagem(id) {
        const viagem = this.state.viagens.find(v => v.id === id);
        if (viagem) {
            this.showViagemForm(viagem);
        }
    },

    async deleteViagem(id) {
        if (!confirm('Tem certeza que deseja excluir esta viagem?')) return;
        
        this.showLoading();
        try {
            await this.api(`tables/viagens/${id}`, { method: 'DELETE' });
            await this.loadViagens();
            alert('Viagem excluída com sucesso!');
        } finally {
            this.hideLoading();
        }
    },

    // ========================================
    // DESPESAS
    // ========================================

    async loadDespesas() {
        this.showLoading();
        try {
            const data = await this.api('tables/despesas?limit=100&sort=-data_despesa');
            this.state.despesas = data.data || [];
            this.renderDespesas();
        } finally {
            this.hideLoading();
        }
    },

    renderDespesas(despesas = null) {
        const container = document.getElementById('despesasList');
        const despesasToRender = despesas || this.state.despesas;
        
        if (despesasToRender.length === 0) {
            container.innerHTML = '<p class="no-data">Nenhuma despesa encontrada</p>';
            return;
        }
        
        const html = `
            <table>
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Categoria</th>
                        <th>Descrição</th>
                        <th>Caminhão</th>
                        <th>Fornecedor</th>
                        <th>Valor</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${despesasToRender.map(despesa => {
                        const caminhao = this.state.caminhoes.find(c => c.id === despesa.caminhao_id);
                        return `
                            <tr>
                                <td>${this.formatDate(despesa.data_despesa)}</td>
                                <td><span class="badge badge-info">${despesa.categoria}</span></td>
                                <td>${despesa.descricao}</td>
                                <td>${caminhao?.placa || '-'}</td>
                                <td>${despesa.fornecedor || '-'}</td>
                                <td>${this.formatCurrency(despesa.valor)}</td>
                                <td>
                                    <button class="btn btn-primary btn-small" onclick="App.editDespesa('${despesa.id}')">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-danger btn-small" onclick="App.deleteDespesa('${despesa.id}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;
        
        container.innerHTML = html;
    },

    filterDespesas() {
        const searchTerm = document.getElementById('filtroDespesas')?.value.toLowerCase() || '';
        const caminhaoId = document.getElementById('filtroCaminhaoDespesa')?.value || '';
        const categoria = document.getElementById('filtroCategoriaDespesa')?.value || '';
        
        const filtered = this.state.despesas.filter(despesa => {
            const matchSearch = !searchTerm || 
                despesa.descricao.toLowerCase().includes(searchTerm) ||
                (despesa.fornecedor && despesa.fornecedor.toLowerCase().includes(searchTerm));
            
            const matchCaminhao = !caminhaoId || despesa.caminhao_id === caminhaoId;
            const matchCategoria = !categoria || despesa.categoria === categoria;
            
            return matchSearch && matchCaminhao && matchCategoria;
        });
        
        this.renderDespesas(filtered);
    },

    showDespesaForm(despesa = null) {
        const isEdit = despesa !== null;
        const title = isEdit ? 'Editar Despesa' : 'Nova Despesa';
        
        const caminhaoOptions = this.state.caminhoes
            .map(c => `<option value="${c.id}" ${despesa?.caminhao_id === c.id ? 'selected' : ''}>${c.placa} - ${c.modelo}</option>`)
            .join('');
        
        const content = `
            <form id="despesaForm">
                <div class="form-row">
                    <div class="form-group">
                        <label>Data da Despesa *</label>
                        <input type="date" name="data_despesa" value="${despesa?.data_despesa ? new Date(despesa.data_despesa).toISOString().split('T')[0] : ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Caminhão *</label>
                        <select name="caminhao_id" required>
                            <option value="">Selecione...</option>
                            ${caminhaoOptions}
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Categoria *</label>
                        <select name="categoria" required>
                            <option value="combustível" ${despesa?.categoria === 'combustível' ? 'selected' : ''}>Combustível</option>
                            <option value="pedágio" ${despesa?.categoria === 'pedágio' ? 'selected' : ''}>Pedágio</option>
                            <option value="manutenção" ${despesa?.categoria === 'manutenção' ? 'selected' : ''}>Manutenção</option>
                            <option value="pneu" ${despesa?.categoria === 'pneu' ? 'selected' : ''}>Pneu</option>
                            <option value="seguro" ${despesa?.categoria === 'seguro' ? 'selected' : ''}>Seguro</option>
                            <option value="licenciamento" ${despesa?.categoria === 'licenciamento' ? 'selected' : ''}>Licenciamento</option>
                            <option value="multa" ${despesa?.categoria === 'multa' ? 'selected' : ''}>Multa</option>
                            <option value="outros" ${despesa?.categoria === 'outros' ? 'selected' : ''}>Outros</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Valor (R$) *</label>
                        <input type="number" step="0.01" name="valor" value="${despesa?.valor || ''}" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Descrição *</label>
                    <input type="text" name="descricao" value="${despesa?.descricao || ''}" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Fornecedor</label>
                        <input type="text" name="fornecedor" value="${despesa?.fornecedor || ''}">
                    </div>
                    <div class="form-group">
                        <label>Documento Fiscal</label>
                        <input type="text" name="documento" value="${despesa?.documento || ''}">
                    </div>
                </div>
                <div class="form-group">
                    <label>Observações</label>
                    <textarea name="observacoes">${despesa?.observacoes || ''}</textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="App.closeModal()">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar
                    </button>
                </div>
            </form>
        `;
        
        this.showModal(title, content);
        
        document.getElementById('despesaForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            this.showLoading();
            try {
                if (isEdit) {
                    await this.api(`tables/despesas/${despesa.id}`, {
                        method: 'PUT',
                        body: JSON.stringify(data)
                    });
                } else {
                    await this.api('tables/despesas', {
                        method: 'POST',
                        body: JSON.stringify(data)
                    });
                }
                
                this.closeModal();
                await this.loadDespesas();
                alert(isEdit ? 'Despesa atualizada com sucesso!' : 'Despesa cadastrada com sucesso!');
            } finally {
                this.hideLoading();
            }
        });
    },

    async editDespesa(id) {
        const despesa = this.state.despesas.find(d => d.id === id);
        if (despesa) {
            this.showDespesaForm(despesa);
        }
    },

    async deleteDespesa(id) {
        if (!confirm('Tem certeza que deseja excluir esta despesa?')) return;
        
        this.showLoading();
        try {
            await this.api(`tables/despesas/${id}`, { method: 'DELETE' });
            await this.loadDespesas();
            alert('Despesa excluída com sucesso!');
        } finally {
            this.hideLoading();
        }
    },

    // Continua na próxima parte...
    
    // ========================================
    // MANUTENÇÕES
    // ========================================

    async loadManutencoes() {
        this.showLoading();
        try {
            const data = await this.api('tables/manutencoes?limit=100&sort=-data_manutencao');
            this.state.manutencoes = data.data || [];
            this.renderManutencoes();
        } finally {
            this.hideLoading();
        }
    },

    renderManutencoes(manutencoes = null) {
        const container = document.getElementById('manutencoesList');
        const manutencoesToRender = manutencoes || this.state.manutencoes;
        
        if (manutencoesToRender.length === 0) {
            container.innerHTML = '<p class="no-data">Nenhuma manutenção encontrada</p>';
            return;
        }
        
        const html = `
            <table>
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>Tipo</th>
                        <th>Caminhão</th>
                        <th>Descrição</th>
                        <th>KM Realizada</th>
                        <th>Próxima KM</th>
                        <th>Valor</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${manutencoesToRender.map(manutencao => {
                        const caminhao = this.state.caminhoes.find(c => c.id === manutencao.caminhao_id);
                        return `
                            <tr>
                                <td>${this.formatDate(manutencao.data_manutencao)}</td>
                                <td><span class="badge badge-${manutencao.tipo === 'preventiva' ? 'info' : 'warning'}">${manutencao.tipo}</span></td>
                                <td>${caminhao?.placa || '-'}</td>
                                <td>${manutencao.descricao}</td>
                                <td>${this.formatNumber(manutencao.km_realizada)} km</td>
                                <td>${manutencao.proxima_km ? this.formatNumber(manutencao.proxima_km) + ' km' : '-'}</td>
                                <td>${this.formatCurrency(manutencao.valor)}</td>
                                <td>${this.getStatusBadge(manutencao.status)}</td>
                                <td>
                                    <button class="btn btn-primary btn-small" onclick="App.editManutencao('${manutencao.id}')">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-danger btn-small" onclick="App.deleteManutencao('${manutencao.id}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;
        
        container.innerHTML = html;
    },

    filterManutencoes() {
        const caminhaoId = document.getElementById('filtroCaminhaoManutencao')?.value || '';
        const tipo = document.getElementById('filtroTipoManutencao')?.value || '';
        const status = document.getElementById('filtroStatusManutencao')?.value || '';
        
        const filtered = this.state.manutencoes.filter(manutencao => {
            const matchCaminhao = !caminhaoId || manutencao.caminhao_id === caminhaoId;
            const matchTipo = !tipo || manutencao.tipo === tipo;
            const matchStatus = !status || manutencao.status === status;
            
            return matchCaminhao && matchTipo && matchStatus;
        });
        
        this.renderManutencoes(filtered);
    },

    showManutencaoForm(manutencao = null) {
        const isEdit = manutencao !== null;
        const title = isEdit ? 'Editar Manutenção' : 'Nova Manutenção';
        
        const caminhaoOptions = this.state.caminhoes
            .map(c => `<option value="${c.id}" ${manutencao?.caminhao_id === c.id ? 'selected' : ''}>${c.placa} - ${c.modelo}</option>`)
            .join('');
        
        const content = `
            <form id="manutencaoForm">
                <div class="form-row">
                    <div class="form-group">
                        <label>Caminhão *</label>
                        <select name="caminhao_id" required>
                            <option value="">Selecione...</option>
                            ${caminhaoOptions}
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Data da Manutenção *</label>
                        <input type="date" name="data_manutencao" value="${manutencao?.data_manutencao ? new Date(manutencao.data_manutencao).toISOString().split('T')[0] : ''}" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Tipo *</label>
                        <select name="tipo" required>
                            <option value="preventiva" ${manutencao?.tipo === 'preventiva' ? 'selected' : ''}>Preventiva</option>
                            <option value="corretiva" ${manutencao?.tipo === 'corretiva' ? 'selected' : ''}>Corretiva</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status *</label>
                        <select name="status" required>
                            <option value="pendente" ${manutencao?.status === 'pendente' ? 'selected' : ''}>Pendente</option>
                            <option value="agendada" ${manutencao?.status === 'agendada' ? 'selected' : ''}>Agendada</option>
                            <option value="realizada" ${manutencao?.status === 'realizada' ? 'selected' : ''}>Realizada</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>Descrição do Serviço *</label>
                    <textarea name="descricao" required>${manutencao?.descricao || ''}</textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>KM Realizada *</label>
                        <input type="number" name="km_realizada" value="${manutencao?.km_realizada || ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Próxima KM (Preventiva)</label>
                        <input type="number" name="proxima_km" value="${manutencao?.proxima_km || ''}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Valor (R$) *</label>
                        <input type="number" step="0.01" name="valor" value="${manutencao?.valor || ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Oficina</label>
                        <input type="text" name="oficina" value="${manutencao?.oficina || ''}">
                    </div>
                </div>
                <div class="form-group">
                    <label>Observações</label>
                    <textarea name="observacoes">${manutencao?.observacoes || ''}</textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="App.closeModal()">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar
                    </button>
                </div>
            </form>
        `;
        
        this.showModal(title, content);
        
        document.getElementById('manutencaoForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            this.showLoading();
            try {
                if (isEdit) {
                    await this.api(`tables/manutencoes/${manutencao.id}`, {
                        method: 'PUT',
                        body: JSON.stringify(data)
                    });
                } else {
                    await this.api('tables/manutencoes', {
                        method: 'POST',
                        body: JSON.stringify(data)
                    });
                }
                
                this.closeModal();
                await this.loadManutencoes();
                alert(isEdit ? 'Manutenção atualizada com sucesso!' : 'Manutenção cadastrada com sucesso!');
            } finally {
                this.hideLoading();
            }
        });
    },

    async editManutencao(id) {
        const manutencao = this.state.manutencoes.find(m => m.id === id);
        if (manutencao) {
            this.showManutencaoForm(manutencao);
        }
    },

    async deleteManutencao(id) {
        if (!confirm('Tem certeza que deseja excluir esta manutenção?')) return;
        
        this.showLoading();
        try {
            await this.api(`tables/manutencoes/${id}`, { method: 'DELETE' });
            await this.loadManutencoes();
            alert('Manutenção excluída com sucesso!');
        } finally {
            this.hideLoading();
        }
    },

    // ========================================
    // DOCUMENTOS
    // ========================================

    async loadDocumentos() {
        this.showLoading();
        try {
            const data = await this.api('tables/documentos?limit=100&sort=data_vencimento');
            this.state.documentos = data.data || [];
            
            // Atualizar status dos documentos
            const hoje = new Date();
            const proximosMeses = new Date(hoje);
            proximosMeses.setMonth(hoje.getMonth() + 1);
            
            for (const doc of this.state.documentos) {
                const vencimento = new Date(doc.data_vencimento);
                let novoStatus = 'válido';
                
                if (vencimento < hoje) {
                    novoStatus = 'vencido';
                } else if (vencimento < proximosMeses) {
                    novoStatus = 'vencendo';
                }
                
                if (doc.status !== novoStatus) {
                    await this.api(`tables/documentos/${doc.id}`, {
                        method: 'PATCH',
                        body: JSON.stringify({ status: novoStatus })
                    });
                    doc.status = novoStatus;
                }
            }
            
            this.renderDocumentos();
        } finally {
            this.hideLoading();
        }
    },

    renderDocumentos(documentos = null) {
        const container = document.getElementById('documentosList');
        const documentosToRender = documentos || this.state.documentos;
        
        if (documentosToRender.length === 0) {
            container.innerHTML = '<p class="no-data">Nenhum documento encontrado</p>';
            return;
        }
        
        const html = `
            <table>
                <thead>
                    <tr>
                        <th>Tipo</th>
                        <th>Número</th>
                        <th>Entidade</th>
                        <th>Emissão</th>
                        <th>Vencimento</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    ${documentosToRender.map(doc => {
                        let entidadeNome = '-';
                        if (doc.tipo_entidade === 'caminhão') {
                            const caminhao = this.state.caminhoes.find(c => c.id === doc.entidade_id);
                            entidadeNome = caminhao ? `${caminhao.placa}` : '-';
                        } else if (doc.tipo_entidade === 'motorista') {
                            const motorista = this.state.motoristas.find(m => m.id === doc.entidade_id);
                            entidadeNome = motorista ? motorista.nome : '-';
                        }
                        
                        return `
                            <tr>
                                <td><span class="badge badge-info">${doc.tipo_documento}</span></td>
                                <td>${doc.numero_documento}</td>
                                <td>${doc.tipo_entidade}: ${entidadeNome}</td>
                                <td>${this.formatDate(doc.data_emissao)}</td>
                                <td>${this.formatDate(doc.data_vencimento)}</td>
                                <td>${this.getStatusBadge(doc.status)}</td>
                                <td>
                                    <button class="btn btn-primary btn-small" onclick="App.editDocumento('${doc.id}')">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-danger btn-small" onclick="App.deleteDocumento('${doc.id}')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        `;
        
        container.innerHTML = html;
    },

    filterDocumentos() {
        const tipoEntidade = document.getElementById('filtroTipoEntidade')?.value || '';
        const tipoDocumento = document.getElementById('filtroTipoDocumento')?.value || '';
        const status = document.getElementById('filtroStatusDocumento')?.value || '';
        
        const filtered = this.state.documentos.filter(doc => {
            const matchTipoEntidade = !tipoEntidade || doc.tipo_entidade === tipoEntidade;
            const matchTipoDocumento = !tipoDocumento || doc.tipo_documento === tipoDocumento;
            const matchStatus = !status || doc.status === status;
            
            return matchTipoEntidade && matchTipoDocumento && matchStatus;
        });
        
        this.renderDocumentos(filtered);
    },

    showDocumentoForm(documento = null) {
        const isEdit = documento !== null;
        const title = isEdit ? 'Editar Documento' : 'Novo Documento';
        
        const content = `
            <form id="documentoForm">
                <div class="form-row">
                    <div class="form-group">
                        <label>Tipo de Entidade *</label>
                        <select name="tipo_entidade" id="tipoEntidade" required>
                            <option value="">Selecione...</option>
                            <option value="caminhão" ${documento?.tipo_entidade === 'caminhão' ? 'selected' : ''}>Caminhão</option>
                            <option value="motorista" ${documento?.tipo_entidade === 'motorista' ? 'selected' : ''}>Motorista</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Selecione *</label>
                        <select name="entidade_id" id="entidadeId" required>
                            <option value="">Selecione o tipo primeiro...</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Tipo de Documento *</label>
                        <select name="tipo_documento" required>
                            <option value="CNH" ${documento?.tipo_documento === 'CNH' ? 'selected' : ''}>CNH</option>
                            <option value="CRLV" ${documento?.tipo_documento === 'CRLV' ? 'selected' : ''}>CRLV</option>
                            <option value="seguro" ${documento?.tipo_documento === 'seguro' ? 'selected' : ''}>Seguro</option>
                            <option value="ANTT" ${documento?.tipo_documento === 'ANTT' ? 'selected' : ''}>ANTT</option>
                            <option value="IPVA" ${documento?.tipo_documento === 'IPVA' ? 'selected' : ''}>IPVA</option>
                            <option value="outros" ${documento?.tipo_documento === 'outros' ? 'selected' : ''}>Outros</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Número do Documento *</label>
                        <input type="text" name="numero_documento" value="${documento?.numero_documento || ''}" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Data de Emissão *</label>
                        <input type="date" name="data_emissao" value="${documento?.data_emissao ? new Date(documento.data_emissao).toISOString().split('T')[0] : ''}" required>
                    </div>
                    <div class="form-group">
                        <label>Data de Vencimento *</label>
                        <input type="date" name="data_vencimento" value="${documento?.data_vencimento ? new Date(documento.data_vencimento).toISOString().split('T')[0] : ''}" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Observações</label>
                    <textarea name="observacoes">${documento?.observacoes || ''}</textarea>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="App.closeModal()">Cancelar</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Salvar
                    </button>
                </div>
            </form>
        `;
        
        this.showModal(title, content);
        
        // Popular entidades quando selecionar o tipo
        const tipoEntidade = document.getElementById('tipoEntidade');
        const entidadeId = document.getElementById('entidadeId');
        
        const popularEntidades = () => {
            const tipo = tipoEntidade.value;
            entidadeId.innerHTML = '<option value="">Selecione...</option>';
            
            if (tipo === 'caminhão') {
                this.state.caminhoes.forEach(c => {
                    const option = document.createElement('option');
                    option.value = c.id;
                    option.textContent = `${c.placa} - ${c.modelo}`;
                    if (documento?.entidade_id === c.id) option.selected = true;
                    entidadeId.appendChild(option);
                });
            } else if (tipo === 'motorista') {
                this.state.motoristas.forEach(m => {
                    const option = document.createElement('option');
                    option.value = m.id;
                    option.textContent = m.nome;
                    if (documento?.entidade_id === m.id) option.selected = true;
                    entidadeId.appendChild(option);
                });
            }
        };
        
        tipoEntidade.addEventListener('change', popularEntidades);
        
        // Popular na edição
        if (isEdit) {
            popularEntidades();
        }
        
        document.getElementById('documentoForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData);
            
            // Calcular status
            const hoje = new Date();
            const vencimento = new Date(data.data_vencimento);
            const proximosMeses = new Date(hoje);
            proximosMeses.setMonth(hoje.getMonth() + 1);
            
            if (vencimento < hoje) {
                data.status = 'vencido';
            } else if (vencimento < proximosMeses) {
                data.status = 'vencendo';
            } else {
                data.status = 'válido';
            }
            
            this.showLoading();
            try {
                if (isEdit) {
                    await this.api(`tables/documentos/${documento.id}`, {
                        method: 'PUT',
                        body: JSON.stringify(data)
                    });
                } else {
                    await this.api('tables/documentos', {
                        method: 'POST',
                        body: JSON.stringify(data)
                    });
                }
                
                this.closeModal();
                await this.loadDocumentos();
                alert(isEdit ? 'Documento atualizado com sucesso!' : 'Documento cadastrado com sucesso!');
            } finally {
                this.hideLoading();
            }
        });
    },

    async editDocumento(id) {
        const documento = this.state.documentos.find(d => d.id === id);
        if (documento) {
            this.showDocumentoForm(documento);
        }
    },

    async deleteDocumento(id) {
        if (!confirm('Tem certeza que deseja excluir este documento?')) return;
        
        this.showLoading();
        try {
            await this.api(`tables/documentos/${id}`, { method: 'DELETE' });
            await this.loadDocumentos();
            alert('Documento excluído com sucesso!');
        } finally {
            this.hideLoading();
        }
    },

    // ========================================
    // RELATÓRIOS
    // ========================================

    initRelatorios() {
        // Definir mês atual como padrão
        const hoje = new Date();
        const mesAtual = hoje.toISOString().substring(0, 7);
        document.getElementById('filtroMesRelatorio').value = mesAtual;
        
        this.gerarRelatorio();
    },

    async gerarRelatorio() {
        this.showLoading();
        try {
            const mesRelatorio = document.getElementById('filtroMesRelatorio')?.value;
            const caminhaoId = document.getElementById('filtroCaminhaoRelatorio')?.value;
            
            if (!mesRelatorio) {
                alert('Selecione um mês para gerar o relatório');
                return;
            }
            
            const [ano, mes] = mesRelatorio.split('-');
            const dataInicio = new Date(ano, mes - 1, 1);
            const dataFim = new Date(ano, mes, 0, 23, 59, 59);
            
            // Filtrar dados do período
            let viagensPeriodo = this.state.viagens.filter(v => {
                const dataViagem = new Date(v.data_viagem);
                const matchPeriodo = dataViagem >= dataInicio && dataViagem <= dataFim;
                const matchCaminhao = !caminhaoId || v.caminhao_id === caminhaoId;
                return matchPeriodo && matchCaminhao;
            });
            
            let despesasPeriodo = this.state.despesas.filter(d => {
                const dataDespesa = new Date(d.data_despesa);
                const matchPeriodo = dataDespesa >= dataInicio && dataDespesa <= dataFim;
                const matchCaminhao = !caminhaoId || d.caminhao_id === caminhaoId;
                return matchPeriodo && matchCaminhao;
            });
            
            // Calcular totais
            const totalFaturamento = viagensPeriodo.reduce((sum, v) => sum + (v.valor_frete || 0), 0);
            const totalDespesas = despesasPeriodo.reduce((sum, d) => sum + (d.valor || 0), 0);
            const totalComissoes = viagensPeriodo.reduce((sum, v) => sum + (v.valor_comissao || 0), 0);
            const lucroLiquido = totalFaturamento - totalDespesas - totalComissoes;
            
            // Atualizar cards
            document.getElementById('relatorioFaturamento').textContent = this.formatCurrency(totalFaturamento);
            document.getElementById('relatorioDespesas').textContent = this.formatCurrency(totalDespesas);
            document.getElementById('relatorioComissoes').textContent = this.formatCurrency(totalComissoes);
            document.getElementById('relatorioLucro').textContent = this.formatCurrency(lucroLiquido);
            
            // Gráfico de despesas por categoria
            const despesasPorCategoria = {};
            despesasPeriodo.forEach(d => {
                despesasPorCategoria[d.categoria] = (despesasPorCategoria[d.categoria] || 0) + d.valor;
            });
            
            this.renderDespesasChart(despesasPorCategoria);
            
            // Gráfico de faturamento por caminhão
            const faturamentoPorCaminhao = {};
            viagensPeriodo.forEach(v => {
                const caminhao = this.state.caminhoes.find(c => c.id === v.caminhao_id);
                const placa = caminhao ? caminhao.placa : 'Desconhecido';
                faturamentoPorCaminhao[placa] = (faturamentoPorCaminhao[placa] || 0) + v.valor_frete;
            });
            
            this.renderFaturamentoChart(faturamentoPorCaminhao);
            
        } finally {
            this.hideLoading();
        }
    },

    renderDespesasChart(data) {
        const ctx = document.getElementById('despesasChart');
        
        // Destruir chart anterior se existir
        if (window.despesasChartInstance) {
            window.despesasChartInstance.destroy();
        }
        
        window.despesasChartInstance = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: Object.keys(data),
                datasets: [{
                    data: Object.values(data),
                    backgroundColor: [
                        '#2563eb',
                        '#10b981',
                        '#f59e0b',
                        '#ef4444',
                        '#3b82f6',
                        '#8b5cf6',
                        '#ec4899',
                        '#14b8a6'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    },

    renderFaturamentoChart(data) {
        const ctx = document.getElementById('faturamentoChart');
        
        // Destruir chart anterior se existir
        if (window.faturamentoChartInstance) {
            window.faturamentoChartInstance.destroy();
        }
        
        window.faturamentoChartInstance = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Object.keys(data),
                datasets: [{
                    label: 'Faturamento (R$)',
                    data: Object.values(data),
                    backgroundColor: '#2563eb'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'R$ ' + value.toLocaleString('pt-BR');
                            }
                        }
                    }
                }
            }
        });
    },

    // ========================================
    // UTILITÁRIOS
    // ========================================

    formatCurrency(value) {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(value || 0);
    },

    formatNumber(value) {
        return new Intl.NumberFormat('pt-BR').format(value || 0);
    },

    formatDate(dateString) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleDateString('pt-BR');
    },

    getStatusBadge(status) {
        const badges = {
            'ativo': 'success',
            'inativo': 'secondary',
            'manutenção': 'warning',
            'pendente': 'warning',
            'pago': 'success',
            'atrasado': 'danger',
            'agendada': 'info',
            'realizada': 'success',
            'válido': 'success',
            'vencendo': 'warning',
            'vencido': 'danger'
        };
        
        const badgeClass = badges[status] || 'secondary';
        return `<span class="badge badge-${badgeClass}">${status}</span>`;
    }
};

// App.init() é chamado pelo auth.js após login bem-sucedido
// ou automaticamente se a sessão já estiver ativa
